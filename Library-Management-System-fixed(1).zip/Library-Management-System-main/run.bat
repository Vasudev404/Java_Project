@echo off
cd /d "%~dp0"

if not exist bin\com\bookflow\controller\BookFlowApplication.class (
    echo Not built yet - run build.bat first.
    pause
    exit /b 1
)

echo Starting BookFlow...
java -cp "bin;lib\*" com.bookflow.controller.BookFlowApplication
pause
