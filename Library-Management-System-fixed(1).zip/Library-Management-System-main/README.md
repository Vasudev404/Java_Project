# BookFlow (No Maven)

This is the same BookFlow project (Swing UI, MVC code and SQLite database logic) with Maven removed.

## Run on Windows in VS Code

1. Install JDK 17 or newer and the Java Extension Pack for VS Code.
2. Download the SQLite JDBC driver version 3.46.1.0 from Maven Central:
   https://repo.maven.apache.org/maven2/org/xerial/sqlite-jdbc/3.46.1.0/sqlite-jdbc-3.46.1.0.jar
3. Save the downloaded file as `lib/sqlite-jdbc-3.46.1.0.jar` inside this BookFlow folder.
4. Open this BookFlow folder in VS Code.
5. Double-click `build.bat` (or run `.\build.bat` in the terminal).
6. Run `run.bat` (or `.\run.bat`).

SQLite JDBC is still needed for the existing SQLite database; Maven is not. On first launch, the app creates `bookflow.db`.

Demo accounts:
- Librarian: admin / admin123
- User: user1 / user123

Do not delete the SQLite driver from `lib`; it is required to connect to the database.
