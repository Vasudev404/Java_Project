SQLite JDBC driver folder

Place sqlite-jdbc-3.46.1.0.jar in this folder before building/running.
The original uploaded project did not include the JDBC .jar, and this package
cannot bundle it automatically. Download it from:
https://repo.maven.apache.org/maven2/org/xerial/sqlite-jdbc/3.46.1.0/sqlite-jdbc-3.46.1.0.jar

Keep the downloaded filename exactly: sqlite-jdbc-3.46.1.0.jar
