@echo off
setlocal
cd /d "%~dp0"

where javac >/dev/null 2>nul
if errorlevel 1 (
    echo ERROR: javac not found. Install JDK 17 or newer and make sure it is on PATH.
    echo Check with: javac -version
    pause
    exit /b 1
)

if not exist lib\sqlite-jdbc-3.46.1.0.jar (
    echo ERROR: lib\sqlite-jdbc-3.46.1.0.jar is missing.
    pause
    exit /b 1
)

echo Building BookFlow...
if not exist bin mkdir bin
if exist sources.tmp del sources.tmp
for /r "src\main\java" %%f in (*.java) do echo "%%f">>sources.tmp
javac -encoding UTF-8 -cp "lib\*" -d bin @sources.tmp
set RESULT=%ERRORLEVEL%
del sources.tmp
if not "%RESULT%"=="0" (
    echo.
    echo Compilation failed.
    pause
    exit /b 1
)

echo.
echo Build successful! Now run run.bat
pause
