@echo off
cd /d "%~dp0"

echo Starting BookFlow...

java -cp "bin;lib\sqlite-jdbc-3.46.1.0.jar;lib\slf4j-api-2.0.13.jar;lib\slf4j-simple-2.0.13.jar" com.bookflow.controller.BookFlowApplication

pause