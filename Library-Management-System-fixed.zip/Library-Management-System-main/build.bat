@echo off
setlocal

cd /d "%~dp0"

echo Building BookFlow...

if not exist bin mkdir bin

powershell -NoProfile -ExecutionPolicy Bypass -Command "$src = Get-ChildItem -Path 'src\main\java' -Filter '*.java' -Recurse | ForEach-Object { $_.FullName }; if (-not $src) { Write-Host 'No Java files found'; exit 1 }; & javac -encoding UTF-8 -cp '.;lib\sqlite-jdbc-3.46.1.0.jar' -d bin $src; exit $LASTEXITCODE"

if errorlevel 1 (
    echo.
    echo Compilation failed.
    pause
    exit /b 1
)

echo.
echo Build successful!
pause